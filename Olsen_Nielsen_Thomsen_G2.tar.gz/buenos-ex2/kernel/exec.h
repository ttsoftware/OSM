
#ifndef BUENOS_KERNEL_EXEC_H
#define BUENOS_KERNEL_EXEC_H

int syscall_exec(char const* filename);

#endif /* BUENOS_KERNEL_EXEC_H */