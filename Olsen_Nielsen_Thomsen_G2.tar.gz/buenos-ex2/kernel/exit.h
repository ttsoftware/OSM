
#ifndef BUENOS_KERNEL_EXIT_H
#define BUENOS_KERNEL_EXIT_H

void syscall_exit(int retval);

#endif /* BUENOS_KERNEL_EXIT_H */