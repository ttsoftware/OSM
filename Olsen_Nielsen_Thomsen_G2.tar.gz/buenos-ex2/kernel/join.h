
#ifndef BUENOS_KERNEL_JOIN_H
#define BUENOS_KERNEL_JOIN_H

int syscall_join(int pid);

#endif /* BUENOS_KERNEL_JOIN_H */