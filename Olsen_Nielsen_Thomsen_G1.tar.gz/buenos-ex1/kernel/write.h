#ifndef BUENOS_SYSCALL_WRITE_H
#define BUENOS_SYSCALL_WRITE_H

int syscall_write(int fhandle, const void *buffer, int length);

#endif /* BUENOS_SYSCALL_WRITE_H */
