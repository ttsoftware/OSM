#ifndef BUENOS_SYSCALL_READ_H
#define BUENOS_SYSCALL_READ_H

int syscall_read(int fhandle, void *buffer, int length);

#endif /* BUENOS_SYSCALL_READ_H */
