#include "tests/lib.h"

int main(void) {
	
	printf("4040%d\n",42);

	int x = 42;
	x = x;

	printf("%d\n", x);

	printf("42%d\n", x);

  	return 0;
}